package com.example.demo;

import org.springframework.boot.SpringApplication;
//import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//import com.maven.spring1.Alien;

@SpringBootApplication
public class Learning1Application {

	public static void main(String[] args) {
		ApplicationContext c=SpringApplication.run(Learning1Application.class, args);
		//System.out.println("hello world");

	Alien obj=c.getBean(Alien.class);//dependency injection working
	obj.code();
	
//		Laptop obj1=c.getBean(Laptop.class);
//		obj1.compile();
	
	 // ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
	  //object creation is happening above
	  //above line create a container for you
	 // Alien obj2=(Alien) context.getBean("alien");
    
    obj.code();
	}

}


//when we create a obj with the help of application context we should call obj class is annotated with @component