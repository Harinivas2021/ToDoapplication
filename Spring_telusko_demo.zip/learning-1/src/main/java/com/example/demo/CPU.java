package com.example.demo;

import org.springframework.stereotype.Component;
@Component
public class CPU {
    
	public void function() {
		// TODO Auto-generated method stub
        System.out.println("cpu function");
	}
}
