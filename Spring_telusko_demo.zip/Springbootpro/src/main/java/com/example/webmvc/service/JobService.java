package com.example.webmvc.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.webmvc.model.JobPost;
import com.example.webmvc.repo.JobRepo;

@Service
public class JobService {
    
	@Autowired
	private JobRepo repo;
//	List<JobPost> jobs = new ArrayList<>(Arrays.asList(
//			new JobPost(1,"Java Developer","Description",2,"Java"),
//			new JobPost(2,"Frontend Developer","Description",2,"React"),
//			new JobPost(3,"Data scientist","Description",3,"Python"),
//			new JobPost(4,"Network Engineer","Description",4,"Linux"),
//			new JobPost(5,"Mobilke App Developer","Description",2,"Android studio")
//											));
	
	public void addJob(JobPost jobPost) {
		repo.save(jobPost);
	}
	public List<JobPost> getAllJobs(){
		return repo.findAll();
	}
	
	public JobPost getjob(int postId) {
		return repo.findById(postId).orElse(new JobPost());
	}
	public void updateJob(JobPost jobPost) {
		repo.save(jobPost);
	}
	public void deleteJob(int postId) {
		repo.deleteById(postId);
	}
	public void load() {
		// TODO Auto-generated method stub
		List<JobPost> jobs = new ArrayList<>(Arrays.asList(
				new JobPost(1,"Java Developer","Description",2,"Java"),
				new JobPost(2,"Frontend Developer","Description",2,"React"),
				new JobPost(3,"Data scientist","Description",3,"Python"),
				new JobPost(4,"Network Engineer","Description",4,"Linux"),
				new JobPost(5,"Mobilke App Developer","Description",2,"Android studio")
												));
		repo.saveAll(jobs);
	}
	
}
