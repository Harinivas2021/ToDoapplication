package com.example.webmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootproApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootproApplication.class, args);
	}

}
