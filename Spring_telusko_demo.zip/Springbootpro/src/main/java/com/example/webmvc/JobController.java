package com.example.webmvc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.webmvc.model.JobPost;
import com.example.webmvc.service.JobService;

@Controller
public class JobController {
	@Autowired
	private JobService service;
	
	
	

	@GetMapping("jobPosts")
	public List<JobPost> getAllJobs() {
		return service.getAllJobs();
		
	}
	
	
	
	
	
	@GetMapping("/jobPost/{postId}")
	public JobPost getJob(@PathVariable int postId) {
		return service.getjob(postId);
	}
	
	
	

	@PostMapping("jobPost")
	public JobPost addJob(@RequestBody JobPost jobPost) {
		service.addJob(jobPost);
		return service.getjob(jobPost.getPostId());
	}
	
	
	
	@PutMapping("jobPost")
	public JobPost updateJob(@RequestBody JobPost jobPost) {
		service.updateJob(jobPost);
		return service.getjob(jobPost.getPostId());
	}
	
	
	
	
	@DeleteMapping("jobPost/{postId}")
	public String deleteJob(@PathVariable int postId)
	{
		service.deleteJob(postId);
		return "Deleted";
	}
	
	
	@GetMapping("load")
	public String loadData() {
		service.load();
		return "success";
	}
	
	
}
//@Autowired
//private JobService jobService;
//
//@GetMapping({"/","home"})
//public String hai() {
//	
//	return "home";
//}
//@GetMapping("addjob")
//public String addjob() {
//	
//	return "addjob";
//}
//@PostMapping("handleForm") //DTO
//public String handleForm(JobPost jobPost) {
//	jobService.addJob(jobPost);
//	return "success";
//}
//
//@GetMapping("viewalljobs")
//public String viewjobs(Model m) { //it will gives view to the that view alljobs page
//	List<JobPost> jobs=jobService.getAllJobs();
//	m.addAttribute("jobPosts", jobs);
//	return "viewalljobs";
//}