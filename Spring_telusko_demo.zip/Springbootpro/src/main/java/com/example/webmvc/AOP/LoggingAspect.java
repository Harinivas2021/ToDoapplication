package com.example.webmvc.AOP;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {

	private static final Logger logger=LoggerFactory.getLogger(LoggingAspect.class);
	//* means return type of all 
	//return type,class name.method name(args)

	@Before("execution(* com.example.webmvc.service.JobService.getJob(..))")
	public  void logMethodCall(JoinPoint jp) {
		// TODO Auto-generated method stub
logger.info("Method Called" +jp.getSignature().getName());
	}

}
