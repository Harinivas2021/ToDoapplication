package com.springMicroservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMicroservicesQuizApplicationTests {

	@Test
	void contextLoads() {
	}

}
