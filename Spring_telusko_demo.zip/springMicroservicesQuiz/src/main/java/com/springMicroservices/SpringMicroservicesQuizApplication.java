package com.springMicroservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMicroservicesQuizApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMicroservicesQuizApplication.class, args);
	}

}
