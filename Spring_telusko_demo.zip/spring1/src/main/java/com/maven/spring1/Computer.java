package com.maven.spring1;

public interface Computer {

	
	void compile();
}
