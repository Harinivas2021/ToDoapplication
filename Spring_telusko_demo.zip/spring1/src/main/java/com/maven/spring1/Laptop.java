package com.maven.spring1;

import org.springframework.stereotype.Component;

@Component
public class Laptop implements Computer{

	public void demo() {
		System.out.println("laptop printing");
	}

	
	public Laptop() {
		super();
		System.out.println("constructor in laptop class");
	}


	@Override
	public void compile() {
		// TODO Auto-generated method stub
		System.out.println("compile in laptop");
	}
}
