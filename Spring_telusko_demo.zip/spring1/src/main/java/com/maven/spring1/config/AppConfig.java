package com.maven.spring1.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import com.maven.spring1.Alien;
import com.maven.spring1.Computer;
import com.maven.spring1.Desktop;
import com.maven.spring1.Laptop;

@Configuration
@ComponentScan("com.maven.spring1")
public class AppConfig {
//	//we can give multiple bean names
//	//@Bean(name = {"hai","com1","com2"}) 
//	
//    @Bean
//    //@Scope(value = "prototype")
//	public Desktop desktop() {
//		return new Desktop();
//		
//	}
//    
//    @Bean
//    public Alien alien( Computer com) { //@Qualifier("desktop") it will put in parameters area
//    	Alien obj=new Alien();
//    	
//    	obj.setAge(25);
//       // System.out.println(obj.getAge());
//         obj.setCom(com);;
//    	return obj;
//    	
//    }
//    @Bean
//    @Primary
//	public Laptop laptop() {
//		return new Laptop();
//		
//	}

}
