package com.maven.spring1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.maven.spring1.config.AppConfig;


public class App {
  public static void main(String[] args) {
    //System.out.println("Hello World!");
   
//	  ApplicationContext context=new ClassPathXmlApplicationContext("src/main/resources/spring.xml");
//	  object creation is happening above
//	  above line create a container for you
//	  Alien obj=(Alien) context.getBean("alien");
//    obj.setAge(21);
//    obj.code();
	  
	  //java based config

	  ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
	  
	  Alien obj=(Alien) context.getBean(Alien.class);
	   System.out.println(obj.getAge());
	   obj.code();
	  
//	  Desktop dt=context.getBean("desktop",Desktop.class); //desktop is a bean  name 
//	  //bean class method name is a bean name
//	  dt.compile();
//	  Desktop dt1=context.getBean(Desktop.class); //desktop is a bean  name 
//	  
//	  dt.compile();
	  
	  
	  
	  
  }
}
