package com.maven.spring1;

import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Primary
@Scope("prototype")
public class Desktop implements Computer {

	public void compile() {
		System.out.println("compile in desktop");
	}

	public Desktop() {
		super();
		System.out.println("desktop contructor initialized");
	}
}
