package com.maven.spring1;

import java.beans.ConstructorProperties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//import org.springframework.stereotype.Component;

@Component
//@Component("com2") //com2 is a bean name when we change here have to change in qualifier
public class Alien {
 
	@Value("24")
	private int age;  //age is a property tag of XML 
	//@Autowired //field based injection
	//@Qualifier("desktop")
	private Computer com;
	
	
	public Alien() {
		super();
		System.out.println("construtor for alien class");
	}
	

	public Computer getCom() {
		return com;
	}

	@Autowired    //setter based injection
	@Qualifier("laptop")//when we put qualifier it will first execute than primary
	public void setCom(Computer com) {
		this.com = com;
	}

    @ConstructorProperties({"age","com"})
	public Alien(int age, Computer com) {
		super();
		this.age = age;
		this.com = com;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public void code() {
		// TODO Auto-generated method stub
System.out.println("coding in alien");
 com.compile();
	}



}
