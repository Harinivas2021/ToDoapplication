package com.springsecurityDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecurityDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
