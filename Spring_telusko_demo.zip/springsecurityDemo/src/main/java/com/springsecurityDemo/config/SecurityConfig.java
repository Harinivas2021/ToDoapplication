package com.springsecurityDemo.config;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;

import org.springframework.security.web.SecurityFilterChain;
//below method or function will broke the spring security
@SuppressWarnings("deprecation")
@Configuration
@EnableWebSecurity
public class SecurityConfig {
	@Autowired
	private UserDetailsService userDetailsService;
      
	//@Bean
	public AuthenticationProvider authprovider() {
		
		DaoAuthenticationProvider provider=new DaoAuthenticationProvider();
		
		provider.setUserDetailsService(userDetailsService);
		provider.setPasswordEncoder(NoOpPasswordEncoder.getInstance());
		
		return provider;
		
	}
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		
		
		http.csrf(customizer->customizer.disable());//customizer is a ref name or obj
		http.authorizeHttpRequests(request->request.anyRequest().authenticated());//it will enable all the request and login page in spring security
		//http.formLogin(Customizer.withDefaults());//it will create a formlogin and also we dont want form login when we have stateless
		//above formlogin method we dont put this we will get popup for form login
		http.httpBasic(Customizer.withDefaults());
		http.sessionManagement(session->session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));//it will become stateless,which means it provide different session id
		
		//above statement  we can write below statement like builder statement 
//		http
//		.csrf(customizer->customizer.disable())
//		.authorizeHttpRequests(request->request.anyRequest().authenticated())
//		.httpBasic(Customizer.withDefaults())
//		.sessionManagement(session->session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
		return http.build();
	}
	
//	@Bean
//	public UserDetailsService userdetailsservice() {
//		//this is for learning purpose dont do in production
//		UserDetails user=User
//				.withDefaultPasswordEncoder()
//				.username("Hari")
//				.password("h@123")
//				.roles("USER")
//				.build();
//		
//		
//		UserDetails admin=User
//				.withDefaultPasswordEncoder()
//				.username("admin")
//				.password("admin@123")
//				.roles("ADMIN")
//				.build();
//		return new InMemoryUserDetailsManager(user,admin);//it will return the userdetailsService
//	}
//	
}
