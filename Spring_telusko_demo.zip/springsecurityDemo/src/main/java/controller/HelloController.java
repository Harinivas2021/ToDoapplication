package controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

@RestController
public class HelloController {
 
	@GetMapping("hello")
	public String great(HttpServletRequest request) {
		// TODO Auto-generated method stub
        return "Hello world! "+request.getSession().getId();
	}
	@GetMapping("about")
	public String About(HttpServletRequest request) {
		return "Success "+request.getSession().getId();
	}
}
