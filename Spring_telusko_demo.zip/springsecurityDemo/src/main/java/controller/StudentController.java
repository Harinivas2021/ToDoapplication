package controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import model.Student;

@RestController
public class StudentController {
    
	List<Student> students=new ArrayList<>(List.of(
			new Student(1,"Harinivas","Java"),
			new Student(2,"ramesh","Python"),
			new Student(3,"kiran","Javascript")));
	
	@GetMapping("/csrf-token")//token generating method
	public CsrfToken getcsrfToken(HttpServletRequest request) {
		return  (CsrfToken) request.getAttribute("_csrf");
	}
	@GetMapping("/students")
	public List<Student> getstudents(){
		return students;
	}
	
	@PostMapping("/students")//it will getting error bcoz we have to create CSRF token
	public void addstudent(@RequestBody Student student ) {
		students.add(student);
	}
}
