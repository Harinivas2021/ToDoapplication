package com.dataJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataJpaDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
