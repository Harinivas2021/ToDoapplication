package com.dataJpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.dataJpa.model.Student;

import Repo.StudentRepo;

@SpringBootApplication
public class DataJpaDemoApplication {

	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(DataJpaDemoApplication.class, args);
	
		
		
		Student s1=context.getBean(Student.class);
		Student s2=context.getBean(Student.class);
		Student s3=context.getBean(Student.class);
		
		StudentRepo repo=context.getBean(StudentRepo.class);
		
		s1.setRollNo(101);
		s1.setName("arun");
		s1.setMarks(75);
		
		s2.setRollNo(101);
		s2.setName("arun");
		s2.setMarks(75);

		s3.setRollNo(101);
		s3.setName("arun");
		s3.setMarks(75);
		
		 repo.save(s1);
	}

}
