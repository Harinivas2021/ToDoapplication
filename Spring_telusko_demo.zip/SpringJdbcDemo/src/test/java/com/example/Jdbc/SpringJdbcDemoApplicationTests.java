package com.example.Jdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJdbcDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
