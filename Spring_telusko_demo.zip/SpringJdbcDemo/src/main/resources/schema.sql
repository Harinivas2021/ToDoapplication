create table student(

rollNo int primary key,
name varchar(50),
marks int 

);