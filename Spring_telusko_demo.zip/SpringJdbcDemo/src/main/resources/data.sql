insert into student (rollno,name,marks) values (101,'madhu',92);
insert into student (rollno,name,marks) values (103,'shree',86);
insert into student (rollno,name,marks) values (104,'ranga',97);