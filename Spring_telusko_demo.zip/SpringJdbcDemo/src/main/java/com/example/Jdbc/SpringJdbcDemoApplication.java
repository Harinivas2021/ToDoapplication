package com.example.Jdbc;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.Jdbc.Model.Student;
import com.example.Jdbc.Service.StudentService;

@SpringBootApplication
public class SpringJdbcDemoApplication {

	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(SpringJdbcDemoApplication.class, args);
	  
	Student s=context.getBean(Student.class);
	s.setRollNo(102);
	s.setName("Hari");
	s.setMarks(98);
	StudentService service=context.getBean(StudentService.class);
	service.addStudent(s);
	
	List<Student> students=service.getStudents();
	System.out.println(students);
	
	}

	
}
