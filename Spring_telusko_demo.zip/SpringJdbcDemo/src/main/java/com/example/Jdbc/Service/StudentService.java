package com.example.Jdbc.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Jdbc.Model.Student;
import com.example.Jdbc.Repository.StudentRepository;

@Service
public class StudentService {

	
private StudentRepository Studentrepo;

	
	public StudentRepository getStudentrepo() {
		return Studentrepo;
	}
	@Autowired
	public void setStudentrepo(StudentRepository studentrepo) {
		Studentrepo = studentrepo;
	}
	
	
	public void addStudent(Student s) {
		//System.out.println("added");
		Studentrepo.save(s);
		
	}
	public List<Student> getStudents() {
		
		return Studentrepo.findAll();
	}


}
