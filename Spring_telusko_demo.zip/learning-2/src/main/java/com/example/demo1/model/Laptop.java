package com.example.demo1.model;

import org.springframework.stereotype.Component;

@Component
public class Laptop implements Computer {

	@Override
	public void compile() {
		// TODO Auto-generated method stub
System.out.println("compile in laptop"); 

	}

}
