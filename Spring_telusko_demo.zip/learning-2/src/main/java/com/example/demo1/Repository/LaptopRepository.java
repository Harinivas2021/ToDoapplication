package com.example.demo1.Repository;

import org.springframework.stereotype.Repository;

import com.example.demo1.model.Laptop;

@Repository
public class LaptopRepository   {
 
	public void save(Laptop lap) {
		System.out.println("saving in database");
	}
}
