package com.example.demo1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo1.Repository.LaptopRepository;
import com.example.demo1.model.Laptop;

@Service
public class LaptopService {

	@Autowired
	private LaptopRepository laptopRepository;

	public void addLaptop(Laptop lap) {
		// TODO Auto-generated method stub
	//	System.out.println("service method called");
		laptopRepository.save(lap);
	}

	public boolean IsGoodForProg(Laptop lap) {

		return true;

	}

}
