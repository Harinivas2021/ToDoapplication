package com.example.demo1.model;

public interface Computer {
 void compile();
}
