package com.example.demo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.demo1.model.Alien;
import com.example.demo1.model.Laptop;
import com.example.demo1.service.LaptopService;

@SpringBootApplication
public class Learning2Application {

	public static void main(String[] args) {
		ApplicationContext context=SpringApplication.run(Learning2Application.class, args);
	
		LaptopService service=context.getBean(LaptopService.class);
		Laptop lap=context.getBean(Laptop.class);
		service.addLaptop(lap);
//		Alien obj=context.getBean(Alien.class);
//		System.out.println(obj.getAge());
//		obj.code();
	
	}

}
