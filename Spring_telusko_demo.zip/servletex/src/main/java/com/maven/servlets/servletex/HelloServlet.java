package com.maven.servlets.servletex;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/hello")
public class HelloServlet extends HttpServlet{
	
	
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException {
		
	System.out.println("in Service");
	res.setContentType("text/html");//it is mentioning type of input
	PrintWriter out=res.getWriter();
	out.println("<h2><b>hello world ()</b></h2>");//this line means we are giving a response to client
	
	}

}
