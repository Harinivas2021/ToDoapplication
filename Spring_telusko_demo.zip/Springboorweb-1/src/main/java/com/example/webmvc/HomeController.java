package com.example.webmvc;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class HomeController {
	
	@RequestMapping({"/","Hai"})
	public String home() {
		System.out.println("home method  called!");
		return "index";
	}

	@RequestMapping("add")
	public String add(@RequestParam("num1") int num1, @RequestParam("num2") int num2, Model model) {
         // System.out.println("another 2nd method called");
		int result = num1 + num2;
		model.addAttribute("result", result);

		return "result";
	}
}
