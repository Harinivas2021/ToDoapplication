package com.example.webmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboorweb1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springboorweb1Application.class, args);
	}

}
