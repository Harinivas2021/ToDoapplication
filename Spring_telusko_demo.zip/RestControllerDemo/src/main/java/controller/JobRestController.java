package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RestController;

import model.JobPost;


import service.JobService;

@RestController
public class JobRestController {
	
	@Autowired
	private JobService jobService;
	
	
	@GetMapping("/demo1")
	public String hai() {
		System.out.println("hai1method");
		return "You will see success Hari!";
	}

	@GetMapping(path="/jobposts",produces = {"application/json"} )//it will produce only json data
	//@ResponseBody
	public List<JobPost> getalljobs() {
		return jobService.getAllJobs();
	}	
}
