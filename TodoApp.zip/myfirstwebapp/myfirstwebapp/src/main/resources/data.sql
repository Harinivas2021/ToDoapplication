insert into todo(ID,USERNAME,DESCRIPTION,TARGET_DATE,DONE)
 values (10001,'Harinivas','Learn AWS course',CURRENT_DATE(),false);
 
 insert into todo(ID,USERNAME,DESCRIPTION,TARGET_DATE,DONE)
 values (10002,'Harinivas','Learn Java course',CURRENT_DATE(),false);
 
 insert into todo(ID,USERNAME,DESCRIPTION,TARGET_DATE,DONE)
 values (10003,'Harinivas','Learn GCP course',CURRENT_DATE(),false);
 
 insert into todo(ID,USERNAME,DESCRIPTION,TARGET_DATE,DONE)
 values (10004,'Harinivas','Learn AZURE course',CURRENT_DATE(),false);
 
 insert into todo(ID,USERNAME,DESCRIPTION,TARGET_DATE,DONE)
 values (10005,'Harinivas','Learn REACT course',CURRENT_DATE(),false);