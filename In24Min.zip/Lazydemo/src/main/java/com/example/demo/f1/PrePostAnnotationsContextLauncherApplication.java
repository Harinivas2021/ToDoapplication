package com.example.demo.f1;

import java.util.Arrays;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

@Component
class SomeClass{
	
	private SomeDependency Somedependency;

	public SomeClass(SomeDependency somedependency) {
		super();
		this.Somedependency = somedependency;
		System.out.println("All dependency are ready");
	}

	@PostConstruct
	public void Initialize() {
		Somedependency.getReady();
	}
	
	public void cleanup() {
		// TODO Auto-generated method stub
System.out.println("CLEANUP");
	}
}

@Component
class SomeDependency{

	public void getReady() {
		// TODO Auto-generated method stub
		System.out.println("some logic using some dependency");
	}
	
}
@Configuration
@ComponentScan
public class PrePostAnnotationsContextLauncherApplication {
	
	public static void main(String[] args) {

		try (var context = 
				new AnnotationConfigApplicationContext
					(PrePostAnnotationsContextLauncherApplication.class)) {
			
			System.out.println("Initialization of context is completed");
		Arrays.stream(context.getBeanDefinitionNames()).forEach(System.out::println);//even thoush you didnt call this line also that class b constructor will print in console for prevent that you can use LAZY
			
			
			

		}
	}
}