package com.example.demo;

import java.util.Arrays;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
class ClassA{
	
}
@Component
@Lazy
class ClassB{
	
	private ClassA classA;

	
	public ClassB(ClassA classA){
		
		//logic 
		System.out.println("some initialization logic ");
		this.classA=classA;
		
	}


	public void doSomething() {
		// TODO Auto-generated method stub
		System.out.println("dosomething method");
	}
}
@Configuration
@ComponentScan
public class LazyInitializationLauncherApplication {
	
	public static void main(String[] args) {

		try (var context = 
				new AnnotationConfigApplicationContext
					(LazyInitializationLauncherApplication.class)) {
			
			System.out.println("Initialization of context is completed");
		//	Arrays.stream(context.getBeanDefinitionNames()).forEach(System.out::println);//even thoush you didnt call this line also that class b constructor will print in console for prevent that you can use LAZY
			
			context.getBean(ClassB.class).doSomething();
			

		}
	}
}