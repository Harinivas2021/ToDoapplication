package Beanscope;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LazydemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LazydemoApplication.class, args);
	}

}
