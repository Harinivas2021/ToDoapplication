package Beanscope;

import java.util.Arrays;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
class NormalClass{//when you call normal you will get same hashcode
//	public NormalClass() {
//		// TODO Auto-generated constructor stub
//		System.out.println("Hi");
//	}
}
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
class PrototypeClass{
	
	


	
}
@Configuration
@ComponentScan
public class BeanScopeLauncherApplication {
	
	public static void main(String[] args) {

		try (var context = 
				new AnnotationConfigApplicationContext
					(BeanScopeLauncherApplication.class)) {
			
			//System.out.println("Initialization of context is completed");
		//	Arrays.stream(context.getBeanDefinitionNames()).forEach(System.out::println);//even thoush you didnt call this line also that class b constructor will print in console for prevent that you can use LAZY
			System.out.println(context.getBean(NormalClass.class)); 
			System.out.println(context.getBean(NormalClass.class)); 

			
			
			System.out.println(context.getBean(PrototypeClass.class)); 
			System.out.println(context.getBean(PrototypeClass.class)); 
			System.out.println(context.getBean(PrototypeClass.class)); 


		}
	}
}