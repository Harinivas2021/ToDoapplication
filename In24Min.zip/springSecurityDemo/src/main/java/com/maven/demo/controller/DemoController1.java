package com.maven.demo.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController1 {

	@RequestMapping("/hi")
	//http://localhost:8080/home
	public String demo12() {
		
		return "Success";
	}
}
