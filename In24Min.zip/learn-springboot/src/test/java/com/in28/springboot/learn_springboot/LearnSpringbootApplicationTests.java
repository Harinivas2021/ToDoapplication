package com.in28.springboot.learn_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
