package com.JPA.springboot.learn_jpa_and_hibernate.Course;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.JPA.springboot.learn_jpa_and_hibernate.Course.SpringDataJpa.CourseSpringDataJpaRepository;

//import com.JPA.springboot.learn_jpa_and_hibernate.Course.JPA.CourseRepository;
//import com.JPA.springboot.learn_jpa_and_hibernate.jdbc.CourseJdbcRepository;

@Component
public class CourseCommandLineRunnner implements CommandLineRunner{
     
//	@Autowired              //spring JDBC
//	private CourseJdbcRepository repository;
	
//	@Autowired              //JPA techinic
//	private CourseRepository repository;

	@Autowired             
	private CourseSpringDataJpaRepository  repository;

	
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		repository.save(new Course(1,"Learn AWS JPA!!","In28Minutes"));
		repository.save(new Course(2,"Learn Azure JPA!!","In28Minutes"));
		repository.save(new Course(3,"Learn Devops now!!","In28Minutes"));
		repository.deleteById(1l);//1l means 1 long with its type
		
		System.out.println(repository.findById(2l));
		System.out.println(repository.findById(3l));
        System.out.println(repository.findAll()); 
        System.out.println(repository.count()); 
        System.out.println(repository.findByAuthor("In28Minutes"));
        System.out.println(repository.findByName("Learn Azure JPA!!"));
	}

}
