package Xml.config;

import java.util.Arrays;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;


//@Configuration
//@ComponentScan
public class XmlConfigLauncherApplication {
	
	public static void main(String[] args) {

		try (var context = 
				new ClassPathXmlApplicationContext("contextConfiguration.xml")){
			
			
			//System.out.println("Initialization of context is completed");
			Arrays.stream(context.getBeanDefinitionNames()).forEach(System.out::println);//even thoush you didnt call this line also that class b constructor will print in console for prevent that you can use LAZY
		
			
			System.out.println(context.getBean("name"));
			System.out.println(context.getBean("age"));


		}
	}
}