package com.springtodoapplication.myfirstwebapp.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("name")
public class WelcomeController {
//private Logger logger=LoggerFactory.getLogger(getClass());

	//@Autowired
	//private AuthenticationService authenticationService;
	
	
//public LoginController(AuthenticationService authenticationService) {
//		super();
//		this.authenticationService = authenticationService;
//	}
@RequestMapping(value="/",method = RequestMethod.GET) 
        //http://localhost:8080/login?name=Hari
	public String gotoWelcomePage(ModelMap model) {
    model.put("name", getLoggedInUsername());
	return "welcome";
	}
//@RequestMapping(value="login",method = RequestMethod.POST)  ////before spring security this logic needed...
////http://localhost:8080/login?name=Hari
//	public String gotoWelcomePage(@RequestParam String name,@RequestParam String password,ModelMap model) {
////how can we pass requestparam that time we can use modelMap 
//	if(authenticationService.authenticate(name, password)) {
//		
//	
//	
//	model.put("name", name);
//	model.put("password", password);
//	return "welcome";
//	}
//	model.put("errorMessage", "invalid credentials,please try again....");
//	return "login";
//}

private String getLoggedInUsername() {
	
	Authentication authentication = 
			SecurityContextHolder.getContext().getAuthentication();
return authentication.getName();

}
}
